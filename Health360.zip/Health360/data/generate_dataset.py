"""Generate a synthetic patient dataset for Health360 (no real patient data)."""
import numpy as np
import pandas as pd

rng = np.random.default_rng(42)
N = 2000

age = rng.integers(18, 90, N)
gender = rng.choice(["Male", "Female"], N)
bmi = np.clip(rng.normal(27, 5.5, N), 15, 50).round(1)
systolic = np.clip(rng.normal(120 + (age - 18) * 0.35, 15, N), 90, 200).round(0)
chol = np.clip(rng.normal(190 + (bmi - 27) * 2, 35, N), 120, 330).round(0)
glucose = np.clip(rng.normal(98 + (bmi - 27) * 1.5, 25, N), 70, 300).round(0)
smoking = rng.choice(["Never", "Former", "Current"], N, p=[0.55, 0.25, 0.20])
alcohol = rng.choice(["Non-drinker", "Moderate", "Heavy"], N, p=[0.4, 0.45, 0.15])
exercise = rng.choice(["Low", "Medium", "High"], N, p=[0.35, 0.40, 0.25])

def z(x): return (x - x.mean()) / x.std()
smoke_s = pd.Series(smoking).map({"Never": 0, "Former": 0.5, "Current": 1}).values
alc_s = pd.Series(alcohol).map({"Non-drinker": 0, "Moderate": 0.2, "Heavy": 1}).values
ex_s = pd.Series(exercise).map({"Low": 1, "Medium": 0.4, "High": 0}).values

base = 0.9*z(age) + 0.5*z(bmi) + 0.6*z(systolic) + 0.5*z(chol) + 0.6*z(glucose) \
       + 0.6*smoke_s + 0.3*alc_s + 0.5*ex_s

def prob(shift, w=1.0):
    return 1 / (1 + np.exp(-(w*base + shift)))

heart = rng.random(N) < prob(-2.6)
diabetes = rng.random(N) < prob(-2.4)
stroke = rng.random(N) < prob(-3.4)

sick = heart | diabetes | stroke
fatigue = rng.random(N) < np.where(sick, 0.55, 0.15)
chest_pain = rng.random(N) < np.where(heart, 0.65, 0.08)
dizziness = rng.random(N) < np.where(stroke | heart, 0.45, 0.10)

df = pd.DataFrame({
    "Patient_ID": [f"P{i:05d}" for i in range(1, N + 1)],
    "Age": age, "Gender": gender, "BMI": bmi,
    "Systolic_BP": systolic, "Cholesterol": chol, "Glucose": glucose,
    "Smoking": smoking, "Alcohol": alcohol, "Exercise_Level": exercise,
    "Fatigue": fatigue.astype(int), "Chest_Pain": chest_pain.astype(int),
    "Dizziness": dizziness.astype(int),
    "Heart_Disease": heart.astype(int), "Diabetes": diabetes.astype(int),
    "Stroke": stroke.astype(int),
})
df.to_csv("data/health360_raw.csv", index=False)
print("Saved data/health360_raw.csv", df.shape)
