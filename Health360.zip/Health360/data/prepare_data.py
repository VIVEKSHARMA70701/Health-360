"""Clean the raw data and add derived fields used in Tableau."""
import pandas as pd

df = pd.read_csv("data/health360_raw.csv")

# --- Cleaning ---
df = df.drop_duplicates("Patient_ID").dropna()
df = df[(df["Age"].between(0, 120)) & (df["BMI"].between(10, 70))]

# --- Derived fields ---
df["Age_Group"] = pd.cut(df["Age"], [0, 29, 44, 59, 74, 120],
                         labels=["18-29", "30-44", "45-59", "60-74", "75+"])
df["BMI_Category"] = pd.cut(df["BMI"], [0, 18.5, 25, 30, 100],
                            labels=["Underweight", "Normal", "Overweight", "Obese"])
df["BP_Category"] = pd.cut(df["Systolic_BP"], [0, 120, 130, 140, 300],
                           labels=["Normal", "Elevated", "Stage 1 HTN", "Stage 2 HTN"])
df["Disease_Count"] = df[["Heart_Disease", "Diabetes", "Stroke"]].sum(axis=1)

# Simple transparent risk score (0-10) from risk factors
score = (
    (df["Age"] >= 60).astype(int) + (df["BMI"] >= 30).astype(int)
    + (df["Systolic_BP"] >= 140).astype(int) + (df["Cholesterol"] >= 240).astype(int)
    + (df["Glucose"] >= 126).astype(int)
    + df["Smoking"].map({"Never": 0, "Former": 1, "Current": 2})
    + df["Alcohol"].map({"Non-drinker": 0, "Moderate": 0, "Heavy": 1})
    + (df["Exercise_Level"] == "Low").astype(int)
)
df["Risk_Score"] = score.astype(int)
df["Risk_Level"] = pd.cut(df["Risk_Score"], [-1, 2, 4, 20],
                          labels=["Low", "Medium", "High"])

df.to_csv("data/health360_clean.csv", index=False)
print("Saved data/health360_clean.csv", df.shape)
print(df["Risk_Level"].value_counts())
